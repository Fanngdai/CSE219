/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sample;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author nb
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({sample.JUnit4TestSuite.class,sample.VectorsJUnit3Test.class})
public class MixJUnit3And4TestSuite {

}