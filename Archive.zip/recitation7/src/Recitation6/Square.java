package Recitation6;


import Recitation6.Shapes;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fannydai
 */
public class Square implements Shapes{
    public void draw(){
        System.out.println("Drawing a Square");
    }
}